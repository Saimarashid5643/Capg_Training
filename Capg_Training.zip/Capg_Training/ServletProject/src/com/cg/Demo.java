package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sun.media.jfxmediaimpl.platform.gstreamer.GSTPlatform;

/**
 * Servlet implementation class ServeletD
 */
@WebServlet({ "/Demo", "/bow" })
public class Demo extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Demo() {
		super();
		System.out.println("this is server");

	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		System.out.println("destroy");
	}

	/**
	 * @see Servlet#getServletConfig()
	 */
	public ServletConfig getServletConfig() {
		System.out.println("getServletConfig");
		return null;
	}

	/**
	 * @see Servlet#getServletInfo()
	 */
	public String getServletInfo() {
		System.out.println("getServletInfo");
		return null;

	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
//	protected void service(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//	
//		
//	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doGet");
		String n1 = request.getParameter("num1");
		String n2 = request.getParameter("num2");
		int i1 = Integer.parseInt(n1.trim());
		int i2 = Integer.parseInt(n2.trim());
		int i3 = i1 + i2;
		System.out.println(i3);
		PrintWriter out = response.getWriter();
		out.print("<div>Sum is: " + i3 + "<a href = 'index.html'> click to go back </a>  </div>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("doPost");
		String n1 = request.getParameter("num1");
		String n2 = request.getParameter("num2");
		int i1 = Integer.parseInt(n1.trim());
		int i2 = Integer.parseInt(n2.trim());
		int i3 = i1 + i2;
		System.out.println(i3);
		PrintWriter out = response.getWriter();
		out.print("<div>Sum is: " + i3 + "<a href = 'index.html'> click to go back </a>  </div>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		doGet(request, response);
		
		

	}

}
